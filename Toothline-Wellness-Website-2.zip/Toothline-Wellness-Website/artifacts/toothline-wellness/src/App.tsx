import { useEffect } from "react";
import { Current } from "./components/mockups/toothline-current/Current";
import { ServiceLanding } from "./components/mockups/toothline-services/ServiceLanding";

function updateMetadata(title: string, description: string) {
  document.title = title;

  let metaDescription = document.querySelector<HTMLMetaElement>(
    'meta[name="description"]',
  );
  if (!metaDescription) {
    metaDescription = document.createElement("meta");
    metaDescription.name = "description";
    document.head.append(metaDescription);
  }
  metaDescription.content = description;

  const canonicalUrl = `${window.location.origin}${window.location.pathname}`;
  let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!canonical) {
    canonical = document.createElement("link");
    canonical.rel = "canonical";
    document.head.append(canonical);
  }
  canonical.href = canonicalUrl;

  for (const [property, content] of [
    ["og:title", title],
    ["og:description", description],
    ["og:url", canonicalUrl],
    ["twitter:title", title],
    ["twitter:description", description],
  ]) {
    let tag = document.querySelector<HTMLMetaElement>(
      `meta[property="${property}"], meta[name="${property}"]`,
    );
    if (!tag) {
      tag = document.createElement("meta");
      tag.setAttribute(property.startsWith("og:") ? "property" : "name", property);
      document.head.append(tag);
    }
    tag.content = content;
  }
}

export default function App() {
  const pathname = window.location.pathname.replace(/\/+$/, "") || "/";
  const isServiceRoute = pathname === "/services" || pathname.startsWith("/services/");

  useEffect(() => {
    if (!isServiceRoute) {
      updateMetadata(
        "Toothline Wellness | Laser Dental Care in Pune",
        "Gentle, modern dental and laser care at Toothline Wellness in Wadgaon Sheri, Pune. Meet Dr. Rufi and explore our treatments.",
      );
    }
  }, [isServiceRoute]);

  useEffect(() => {
    const targetId = window.location.hash.slice(1);
    if (!targetId) return;
    const timeout = window.setTimeout(() => {
      document.getElementById(decodeURIComponent(targetId))?.scrollIntoView();
    }, 0);
    return () => window.clearTimeout(timeout);
  }, [pathname]);

  return isServiceRoute ? <ServiceLanding /> : <Current />;
}
