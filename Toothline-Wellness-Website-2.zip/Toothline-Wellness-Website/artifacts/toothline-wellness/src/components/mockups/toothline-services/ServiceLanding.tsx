import { useEffect, useMemo, useState } from 'react'
import {
  ArrowLeft,
  ArrowRight,
  CalendarCheck,
  Phone,
  Search,
  ShieldCheck,
  Star,
} from 'lucide-react'
import { MAPS_LINK } from '../toothline-current/_shared/site'
import { BookingProvider } from '../toothline-current/_shared/booking-provider'
import { Footer } from '../toothline-current/_shared/footer'

type Service = {
  slug: string
  name: string
  description: string
}

type ServiceCategory = {
  slug: string
  name: string
  description: string
  image: string
  imageAlt: string
  services: Service[]
}

const phoneNumber = '+917387494713'
const phoneDisplay = '+91 73874 94713'
const logoPath = '/images/toothline-current-logo-transparent.png'

const categories: ServiceCategory[] = [
  {
    slug: 'preventive-diagnostic-dentistry',
    name: 'Preventive & Diagnostic Dentistry',
    description: 'Small, regular check-ins that help protect a healthy smile.',
    image: '/images/toothline-services-preventive.jpg',
    imageAlt: 'Dentist reviewing a digital scan with a patient',
    services: [
      {
        slug: 'dental-checkups-consultations',
        name: 'Dental Checkups & Consultations',
        description:
          'Routine oral exams help catch changes early and turn questions into a clear, personalised care plan.',
      },
      {
        slug: 'teeth-cleaning-scaling',
        name: 'Teeth Cleaning & Scaling',
        description:
          'A careful professional clean removes plaque and buildup, then polishes teeth for a fresh, healthy-feeling finish.',
      },
      {
        slug: 'dental-x-rays',
        name: 'Dental X-Rays',
        description:
          'Digital images help assess areas that are difficult to see during an exam and guide precise treatment planning.',
      },
      {
        slug: 'mouth-guards-night-guards',
        name: 'Mouth Guards & Night Guards',
        description:
          'Custom-fit guards protect teeth from grinding and help reduce the risk of sports-related dental injury.',
      },
    ],
  },
  {
    slug: 'endodontics-restorative-dentistry',
    name: 'Endodontics & Restorative Dentistry',
    description: 'Thoughtful repair that protects the teeth you already have.',
    image: '/images/toothline-services-endodontics.jpg',
    imageAlt: 'Careful restorative dental work under a microscope',
    services: [
      {
        slug: 'root-canal-treatment',
        name: 'Root Canal Treatment',
        description:
          'Endodontic care removes infection from inside a tooth and restores it, helping you keep your natural smile.',
      },
      {
        slug: 'instrument-fracture-removal',
        name: 'Instrument Fracture Removal',
        description:
          'Specialist retrieval helps remove a separated root-canal instrument while protecting the tooth’s remaining structure.',
      },
      {
        slug: 'dental-fillings-sealants',
        name: 'Dental Fillings & Sealants',
        description:
          'Tooth-coloured restorations repair small cavities, while preventive sealants shield vulnerable grooves from decay.',
      },
    ],
  },
  {
    slug: 'implantology',
    name: 'Implantology',
    description: 'Stable, carefully planned ways to replace missing teeth.',
    image: '/images/toothline-services-implants.jpg',
    imageAlt: 'Dental implant model and digital treatment plan',
    services: [
      {
        slug: 'single-tooth-implants',
        name: 'Single Tooth Implants',
        description:
          'A titanium implant replaces a missing tooth root and supports a lifelike crown designed to blend with your smile.',
      },
      {
        slug: 'immediate-loading-implants',
        name: 'Immediate Loading Implants',
        description:
          'For suitable cases, an implant and temporary restoration are placed on a coordinated same-day treatment plan.',
      },
      {
        slug: 'full-arch-implant-surgery',
        name: 'Full Arch Implant Surgery',
        description:
          'Implant-supported full-arch rehabilitation is planned to restore stability, comfort, and confidence when many teeth are missing.',
      },
    ],
  },
  {
    slug: 'prosthodontics-crowns-bridges-dentures',
    name: 'Prosthodontics',
    description: 'Custom restorations, crowns, bridges, and dentures made to fit.',
    image: '/images/toothline-services-prosthodontics.jpg',
    imageAlt: 'Ceramic crown and tooth shade guide',
    services: [
      {
        slug: 'teeth-crowns-bridges',
        name: 'Teeth Crowns & Bridges',
        description:
          'Custom ceramic, PFM, or zirconia restorations protect weakened teeth and replace missing teeth with a natural-looking result.',
      },
      {
        slug: 'veneers',
        name: 'Veneers',
        description:
          'Thin porcelain or composite veneers refine the visible surfaces of teeth for a balanced, natural-looking smile.',
      },
      {
        slug: 'removable-partial-dentures',
        name: 'Removable Partial Dentures (RPD)',
        description:
          'A custom removable partial denture fills selected gaps and is shaped to fit comfortably around remaining teeth.',
      },
      {
        slug: 'full-dentures',
        name: 'Full Dentures',
        description:
          'Full dentures are tailored to replace a complete arch of teeth with a comfortable, carefully adjusted fit.',
      },
    ],
  },
  {
    slug: 'orthodontics',
    name: 'Orthodontics',
    description: 'Personalised alignment plans for straighter, more comfortable bites.',
    image: '/images/toothline-services-orthodontics.jpg',
    imageAlt: 'Clear aligner and digital orthodontic planning',
    services: [
      {
        slug: 'invisalign-clear-aligners',
        name: 'Invisalign & Clear Aligners',
        description:
          'A series of discreet, removable trays gradually guides teeth toward a straighter smile with planned check-ins.',
      },
      {
        slug: 'orthodontic-braces-realignment',
        name: 'Orthodontic Braces & Realignment',
        description:
          'Braces and cosmetic alignment options address crowding and bite concerns with a treatment plan tailored to you.',
      },
    ],
  },
  {
    slug: 'cosmetic-dentistry',
    name: 'Cosmetic Dentistry',
    description: 'Subtle, considered changes to help your smile feel like yours.',
    image: '/images/toothline-services-cosmetic.jpg',
    imageAlt: 'Dentist and patient discussing a smile shade guide',
    services: [
      {
        slug: 'teeth-whitening',
        name: 'Teeth Whitening',
        description:
          'Professional whitening brightens natural teeth with treatment selected to suit your goals and tooth sensitivity.',
      },
      {
        slug: 'digital-smile-design',
        name: 'Digital Smile Design',
        description:
          'Digital smile planning previews shape and proportion to align your aesthetic goals with a practical treatment plan.',
      },
      {
        slug: 'dental-bonding',
        name: 'Dental Bonding',
        description:
          'Tooth-coloured composite can repair chips, close minor gaps, or improve discolouration with a conservative approach.',
      },
    ],
  },
  {
    slug: 'oral-surgery-periodontics',
    name: 'Oral Surgery & Periodontics',
    description: 'Specialist attention for gums, extractions, and minor oral surgery.',
    image: '/images/toothline-services-periodontics.jpg',
    imageAlt: 'Periodontist preparing a dental laser in a calm treatment room',
    services: [
      {
        slug: 'tooth-extractions',
        name: 'Tooth Extractions',
        description:
          'Simple, wisdom-tooth, and surgical extractions are planned around comfort, safety, and clear aftercare.',
      },
      {
        slug: 'oral-surgery',
        name: 'Oral Surgery',
        description:
          'Minor oral-surgery procedures are assessed and planned with practical guidance before and after treatment.',
      },
      {
        slug: 'periodontal-and-gum-care',
        name: 'Periodontal & Gum Care',
        description:
          'Periodontal care helps manage gingivitis and periodontitis, supporting healthier gums and long-term oral stability.',
      },
      {
        slug: 'laser-dentistry-laser-gum-therapy',
        name: 'Laser Dentistry & Laser Gum Therapy',
        description:
          'Minimally invasive laser techniques target soft-tissue concerns with precision and a gentler recovery experience.',
      },
    ],
  },
  {
    slug: 'pediatric-dentistry',
    name: 'Pediatric Dentistry',
    description: 'Gentle dental care that helps children feel safe and confident.',
    image: '/images/toothline-services-pediatric.jpg',
    imageAlt: 'Friendly pediatric dentist speaking with a child',
    services: [
      {
        slug: 'childrens-dental-care',
        name: 'Children’s Dental Care',
        description:
          'Preventive, restorative, and routine visits are designed to help children feel safe, informed, and at ease.',
      },
    ],
  },
  {
    slug: 'emergency-dental-care',
    name: 'Emergency Dental Care',
    description: 'Prompt, calm guidance when dental pain or injury cannot wait.',
    image: '/images/toothline-services-emergency.jpg',
    imageAlt: 'Dentist listening to a patient during an urgent consultation',
    services: [
      {
        slug: 'emergency-dentistry',
        name: 'Emergency Dentistry',
        description:
          'Urgent assessment for dental pain, trauma, and broken teeth helps identify next steps promptly and thoughtfully.',
      },
    ],
  },
]

const allServices = categories.flatMap((category) =>
  category.services.map((service) => ({ ...service, category })),
)
const serviceCount = allServices.length

function serviceHref(slug: string) {
  return `/services/${encodeURIComponent(slug)}`
}

function Header() {
  return (
    <header className="sticky top-0 z-20 border-b border-[#e8e1d6] bg-[#fbfaf7]/95 backdrop-blur">
      <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between gap-4 px-5 sm:px-8">
        <a href="/" aria-label="Toothline Wellness home">
          <img src={logoPath} alt="Toothline Wellness" className="h-12 w-auto brightness-0 opacity-75" />
        </a>
        <nav className="hidden items-center gap-7 text-sm font-medium text-[#62594e] md:flex" aria-label="Service pages">
          <a className="transition-colors hover:text-[#9b7642]" href="/services">
            All services
          </a>
          <a className="transition-colors hover:text-[#9b7642]" href="/#reviews">
            Our Reviews
          </a>
          <a className="transition-colors hover:text-[#9b7642]" href="/#founder">
            Meet Dr. Rufi
          </a>
          <a className="transition-colors hover:text-[#9b7642]" href="tel:+917387494713">
            Contact
          </a>
        </nav>
        <a
          href={`tel:${phoneNumber}`}
          className="inline-flex items-center gap-2 rounded-full bg-[#645342] px-4 py-2.5 text-xs font-semibold text-[#fffaf2] transition hover:bg-[#4f4234] sm:px-5 sm:text-sm"
        >
          <Phone className="size-4" />
          <span className="hidden sm:inline">Call the clinic</span>
          <span className="sm:hidden">Call</span>
        </a>
      </div>
    </header>
  )
}

function ServicesIndex({ search, onSearch }: { search: string; onSearch: (value: string) => void }) {
  const filteredCategories = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return categories
    return categories
      .map((category) => ({
        ...category,
        services: category.services.filter(
          (service) =>
            service.name.toLowerCase().includes(term) ||
            service.description.toLowerCase().includes(term) ||
            category.name.toLowerCase().includes(term),
        ),
      }))
      .filter((category) => category.services.length > 0)
  }, [search])

  return (
    <>
      <section className="mx-auto max-w-7xl px-5 pb-16 pt-12 sm:px-8 sm:pb-20 sm:pt-16 lg:pt-20">
        <div className="grid items-center gap-10 lg:grid-cols-[0.92fr_1.08fr] lg:gap-16">
          <div className="max-w-xl">
            <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-[#9a7749]">
              <span className="h-px w-8 bg-[#b3905d]" />
              Toothline Wellness · Pune
            </p>
            <h1 className="mt-6 font-serif text-4xl leading-[1.05] text-[#3c342c] sm:text-5xl lg:text-[4.2rem]">
              Every treatment.
              <br />
              <span className="italic text-[#8c7458]">Clearly explained.</span>
            </h1>
            <p className="mt-6 max-w-lg text-base leading-7 text-[#766c60] sm:text-lg">
              Browse {serviceCount} dental services across nine specialties. Find the care you need, then talk it through with our team.
            </p>
            <div className="mt-8 flex flex-wrap gap-3 text-xs font-medium text-[#6f6251]">
              <span className="rounded-full border border-[#dfd5c6] bg-[#f2eee6] px-4 py-2">{serviceCount} services</span>
              <span className="rounded-full border border-[#dfd5c6] bg-[#f2eee6] px-4 py-2">9 specialties</span>
              <span className="rounded-full border border-[#dfd5c6] bg-[#f2eee6] px-4 py-2">Patient-first care</span>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -bottom-4 -left-4 h-full w-full rounded-[2rem] border border-[#c4a477]/50" />
            <div className="relative overflow-hidden rounded-[2rem] bg-[#e9e3d8]">
              <img
                src={categories[0].image}
                alt={categories[0].imageAlt}
                className="aspect-[5/4] w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#32291f]/45 via-transparent to-transparent" />
              <p className="absolute bottom-6 left-6 max-w-sm font-serif text-2xl leading-tight text-white sm:bottom-8 sm:left-8 sm:text-3xl">
                Preventive care starts with a good conversation.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-y border-[#e3ddd2] py-5 sm:mt-20 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#91744e]">Find your service</p>
            <p className="mt-1 text-sm text-[#7e7468]">Search by treatment or specialty.</p>
          </div>
          <label className="relative block w-full sm:max-w-sm">
            <Search className="absolute left-4 top-1/2 size-4 -translate-y-1/2 text-[#998d7d]" />
            <input
              type="search"
              value={search}
              onChange={(event) => onSearch(event.target.value)}
              placeholder="Try “aligners” or “gum care”"
              className="h-12 w-full rounded-full border border-[#ded5c8] bg-[#fffefa] pl-11 pr-4 text-sm text-[#3c342c] outline-none transition placeholder:text-[#aaa092] focus:border-[#a78350] focus:ring-2 focus:ring-[#a78350]/15"
            />
          </label>
        </div>

        <div className="mt-8 grid gap-x-14 gap-y-8 lg:grid-cols-2">
          {filteredCategories.map((category, index) => (
            <section
              key={category.slug}
              className={`border-t border-[#c9b89e] pt-5 ${index === 0 ? 'lg:col-span-2 lg:grid lg:grid-cols-[0.7fr_1.3fr] lg:gap-10' : ''}`}
            >
              <div className="mb-4 flex items-start justify-between gap-5">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#9b7c50]">
                    Specialty {String(categories.findIndex((item) => item.slug === category.slug) + 1).padStart(2, '0')}
                  </p>
                  <h2 className="mt-2 font-serif text-2xl leading-tight text-[#41372e] sm:text-[1.7rem]">
                    {category.name}
                  </h2>
                  <p className="mt-2 max-w-md text-sm leading-relaxed text-[#7c7164]">{category.description}</p>
                </div>
                {index === 0 && (
                  <img
                    src={category.image}
                    alt=""
                    aria-hidden="true"
                    className="hidden h-24 w-36 rounded-2xl object-cover sm:block lg:hidden"
                  />
                )}
              </div>
              <div className={`divide-y divide-[#e8e1d6] ${index === 0 ? 'lg:col-start-2 lg:row-span-1 lg:row-start-1' : ''}`}>
                {category.services.map((service) => (
                  <a
                    key={service.slug}
                    href={serviceHref(service.slug)}
                    className="group flex items-center justify-between gap-4 py-3.5 text-sm font-medium text-[#51473c] transition-colors hover:text-[#997649]"
                  >
                    <span>{service.name}</span>
                    <ArrowRight className="size-4 shrink-0 text-[#b69a72] transition-transform group-hover:translate-x-1" />
                  </a>
                ))}
              </div>
            </section>
          ))}
          {filteredCategories.length === 0 && (
            <div className="rounded-3xl border border-dashed border-[#d1c2ab] bg-[#f2eee6] px-6 py-12 text-center lg:col-span-2">
              <p className="font-serif text-2xl text-[#51473c]">No matching service yet.</p>
              <p className="mt-2 text-sm text-[#7c7164]">Try a shorter search or browse all specialties.</p>
            </div>
          )}
        </div>
      </section>
    </>
  )
}

function ServicePage({ category, service }: { category: ServiceCategory; service: Service }) {
  return (
    <>
      <section className="mx-auto max-w-7xl px-5 pb-16 pt-10 sm:px-8 sm:pb-20 sm:pt-14">
        <a
          href="/services"
          className="inline-flex items-center gap-2 text-sm font-medium text-[#7a6d5c] transition hover:text-[#9b7642]"
        >
          <ArrowLeft className="size-4" />
          All services
        </a>
        <div className="mt-8 grid items-center gap-10 lg:grid-cols-[0.92fr_1.08fr] lg:gap-16">
          <div className="max-w-xl">
            <p className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.23em] text-[#9a7749]">
              <span className="h-px w-8 bg-[#b3905d]" />
              {category.name}
            </p>
            <h1 className="mt-5 font-serif text-4xl leading-[1.08] text-[#3c342c] sm:text-5xl lg:text-[4.2rem]">
              {service.name}
            </h1>
            <p className="mt-6 max-w-lg text-base leading-7 text-[#766c60] sm:text-lg">
              {service.description}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                href={`https://wa.me/${phoneNumber.slice(1)}?text=${encodeURIComponent(`Hello Toothline Wellness, I’d like to discuss ${service.name}.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-full bg-[#645342] px-6 py-3 text-sm font-semibold text-[#fffaf2] transition hover:bg-[#4f4234]"
              >
                <CalendarCheck className="size-4" />
                Discuss this treatment
              </a>
              <a
                href={`tel:${phoneNumber}`}
                className="inline-flex items-center gap-2 rounded-full border border-[#d9cebf] px-5 py-3 text-sm font-medium text-[#5f5345] transition hover:border-[#a78350] hover:text-[#997649]"
              >
                <Phone className="size-4" />
                {phoneDisplay}
              </a>
            </div>
            <p className="mt-5 flex items-center gap-2 text-xs text-[#8a7d6e]">
              <ShieldCheck className="size-4 text-[#9b7c50]" />
              Your dentist will recommend care after an individual assessment.
            </p>
          </div>
          <div className="relative">
            <div className="absolute -bottom-4 -left-4 h-full w-full rounded-[2rem] border border-[#c4a477]/50" />
            <div className="relative overflow-hidden rounded-[2rem] bg-[#e9e3d8]">
              <img
                src={category.image}
                alt={category.imageAlt}
                className="aspect-[5/4] w-full object-cover"
              />
              <div className="absolute bottom-5 left-5 rounded-full border border-white/30 bg-[#3b3026]/45 px-4 py-2 text-xs font-medium text-white backdrop-blur-sm">
                {category.name}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-[#e4ddd1] bg-[#f1eee7]">
        <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-20">
          <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-2xl">
              <p className="text-[11px] font-semibold uppercase tracking-[0.23em] text-[#997649]">
                Patient stories
              </p>
              <h2 className="mt-3 font-serif text-3xl leading-tight text-[#3c342c] sm:text-4xl">
                Reviews for {service.name}
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-6 text-[#766c60] sm:text-base">
                Only original, verified Google reviews should appear here. Reviews for this treatment will be added when the original patient feedback can be confirmed.
              </p>
            </div>
            <a
              href={MAPS_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex w-fit items-center gap-2 rounded-full border border-[#cfc2af] bg-[#fbfaf7] px-5 py-3 text-sm font-semibold text-[#695a47] transition hover:border-[#a78350]"
            >
              <Star className="size-4 text-[#a78350]" />
              View Google profile
            </a>
          </div>
          <div
            id="reviews-source"
            className="mt-9 grid gap-5 rounded-[1.6rem] border border-[#dfd5c6] bg-[#fbfaf7] p-6 sm:grid-cols-[auto_1fr] sm:items-center sm:p-8"
          >
            <div className="flex size-14 items-center justify-center rounded-full bg-[#eee8dc] text-[#9b7c50]">
              <ShieldCheck className="size-6" />
            </div>
            <div>
              <p className="font-serif text-xl text-[#4b4034]">No unverified quotes.</p>
              <p className="mt-2 max-w-3xl text-sm leading-relaxed text-[#7c7164]">
                No unverified review quotes are shown. Visit the clinic’s Google profile while service-matched patient feedback is being confirmed.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-12 sm:px-8 sm:py-16">
        <div className="flex flex-col gap-6 rounded-[1.7rem] bg-[#e9e4da] p-6 sm:flex-row sm:items-center sm:justify-between sm:p-9">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#90724b]">Next step</p>
            <h2 className="mt-2 font-serif text-2xl text-[#40372e] sm:text-3xl">Talk through your options.</h2>
            <p className="mt-2 text-sm text-[#766c60]">Our team can help you plan a visit and answer your first questions.</p>
          </div>
          <a
            href={`tel:${phoneNumber}`}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#645342] px-6 py-3 text-sm font-semibold text-[#fffaf2] transition hover:bg-[#4f4234]"
          >
            Call {phoneDisplay}
            <ArrowRight className="size-4" />
          </a>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-16 sm:px-8">
        <div className="flex items-center justify-between border-t border-[#e3ddd2] pt-5">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[#8f7b61]">More in {category.name}</p>
          <a href="/services" className="text-sm font-medium text-[#79684f] hover:text-[#9b7642]">
            Browse all specialties
          </a>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {category.services
            .filter((item) => item.slug !== service.slug)
            .map((item) => (
              <a
                key={item.slug}
                href={serviceHref(item.slug)}
                className="rounded-full border border-[#ded5c8] bg-[#fbfaf7] px-4 py-2 text-sm text-[#62594e] transition hover:border-[#af8c5d] hover:text-[#8b6e48]"
              >
                {item.name}
              </a>
            ))}
        </div>
      </section>
    </>
  )
}

function NotFound({ slug }: { slug: string }) {
  return (
    <section className="mx-auto max-w-3xl px-5 py-24 text-center sm:px-8">
      <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[#997649]">Service not found</p>
      <h1 className="mt-4 font-serif text-4xl text-[#3c342c]">Let’s find the right care.</h1>
      <p className="mt-3 text-sm text-[#766c60]">No service matches “{slug}”. Browse the complete list instead.</p>
      <a
        href="/services"
        className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#645342] px-5 py-3 text-sm font-semibold text-[#fffaf2]"
      >
        <ArrowLeft className="size-4" />
        Browse all services
      </a>
    </section>
  )
}

export function ServiceLanding() {
  const [search, setSearch] = useState('')
  const path = window.location.pathname.replace(/\/+$/, '')
  let serviceSlug: string | null = null
  if (path !== '/services') {
    const encodedSlug = path.slice('/services/'.length)
    try {
      serviceSlug = decodeURIComponent(encodedSlug)
    } catch {
      serviceSlug = encodedSlug
    }
  }
  const selected = allServices.find((item) => item.slug === serviceSlug)

  useEffect(() => {
    const title = selected
      ? `${selected.name} in Pune | Toothline Wellness`
      : serviceSlug
        ? 'Dental service not found | Toothline Wellness'
        : 'Dental Services in Pune | Toothline Wellness'
    const description = selected
      ? `${selected.description} Discuss ${selected.name.toLowerCase()} with Toothline Wellness in Wadgaon Sheri, Pune.`
      : `Browse ${serviceCount} dental treatments across nine specialties at Toothline Wellness in Wadgaon Sheri, Pune.`
    document.title = title
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]')
    if (!meta) {
      meta = document.createElement('meta')
      meta.name = 'description'
      document.head.append(meta)
    }
    meta.content = description
    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]')
    if (!canonical) {
      canonical = document.createElement('link')
      canonical.rel = 'canonical'
      document.head.append(canonical)
    }
    canonical.href = `${window.location.origin}${window.location.pathname}`
    for (const [property, content] of [
      ['og:title', title],
      ['og:description', description],
      ['og:url', `${window.location.origin}${window.location.pathname}`],
      ['twitter:title', title],
      ['twitter:description', description],
    ]) {
      let tag = document.querySelector<HTMLMetaElement>(
        `meta[property="${property}"], meta[name="${property}"]`,
      )
      if (!tag) {
        tag = document.createElement('meta')
        tag.setAttribute(property.startsWith('og:') ? 'property' : 'name', property)
        document.head.append(tag)
      }
      tag.content = content
    }
  }, [selected, serviceSlug])

  return (
    <BookingProvider>
      <div className="min-h-[100dvh] bg-[#fbfaf7] text-[#3c342c]">
        <Header />
        <main>
          {serviceSlug && selected ? (
            <ServicePage category={selected.category} service={selected} />
          ) : serviceSlug ? (
            <NotFound slug={serviceSlug} />
          ) : (
            <ServicesIndex search={search} onSearch={setSearch} />
          )}
        </main>
        <Footer />
      </div>
    </BookingProvider>
  )
}