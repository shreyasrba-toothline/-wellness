import { Sparkles, HeartPulse, Microscope, Leaf } from 'lucide-react'

const pillars = [
  { icon: Sparkles, title: 'Laser Precision', text: 'State-of-the-art laser technology for accurate, minimally invasive care.' },
  { icon: HeartPulse, title: 'Painless Comfort', text: 'Gentle techniques designed to keep every visit calm and anxiety-free.' },
  { icon: Microscope, title: 'Expert Diagnosis', text: 'Thorough, honest assessments led by a specialist periodontist.' },
  { icon: Leaf, title: 'Preventive Focus', text: 'Long-term oral wellness through education and preventive dentistry.' },
]

export function About() {
  return (
    <section id="about" className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Our Clinic</p>
          <h2 className="mt-3 font-serif text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">A Refined Approach to Modern Dentistry</h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Toothline Wellness blends advanced laser technology with a warm, spa-like environment in the heart of Pune. Every detail is crafted for your comfort, delivering premium care that feels effortless.</p>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p) => <div key={p.title} className="rounded-2xl border border-border bg-card p-7 shadow-sm transition hover:-translate-y-1 hover:shadow-md">
            <span className="flex size-12 items-center justify-center rounded-xl bg-secondary text-primary"><p.icon className="size-6" /></span>
            <h3 className="mt-5 font-serif text-xl font-semibold text-foreground">{p.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.text}</p>
          </div>)}
        </div>
      </div>
    </section>
  )
}