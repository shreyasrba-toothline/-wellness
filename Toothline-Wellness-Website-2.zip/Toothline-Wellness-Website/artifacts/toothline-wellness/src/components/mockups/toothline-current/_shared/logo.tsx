export function Logo({ className = '' }: { className?: string }) {
  return (
    <a
      href="/"
      className={`group block shrink-0 ${className}`}
      aria-label="Toothline Wellness — Laser Dental Care, home"
    >
      <img
        src="/images/toothline-current-logo-transparent.png"
        alt="Toothline Wellness laser dental care"
        className="h-14 w-auto max-w-[190px] object-contain object-left brightness-0 invert sm:h-16 sm:max-w-[220px]"
      />
    </a>
  )
}