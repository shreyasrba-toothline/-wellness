import { useEffect, useState } from 'react'
import { Phone, Menu, X, ChevronDown } from 'lucide-react'
import { Logo } from './logo'
import { useBooking } from './booking-provider'
import { PHONE_DISPLAY, PHONE_TEL } from './site'

const treatments = [
  { label: 'Laser Dentistry', href: '#treatments' },
  { label: 'Gum Care & Periodontics', href: '#treatments' },
  { label: 'Root Canal Treatment', href: '#treatments' },
  { label: 'Dental Implants', href: '#treatments' },
  { label: 'Cosmetic Dentistry', href: '#treatments' },
]
const aboutLinks = [
  { label: 'Our Clinic', href: '#about' },
  { label: 'Our Doctors', href: '#founder' },
]

export function Header() {
  const { openBooking } = useBooking()
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
      scrolled
        ? 'border-b border-border bg-background/90 shadow-sm backdrop-blur-md'
        : 'border-b border-transparent bg-background/60 backdrop-blur-sm'
    }`}>
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          <NavDropdown label="About" items={aboutLinks} />
          <NavDropdown label="Treatments & Specialities" items={treatments} />
          <a href="#reviews" className="rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition hover:bg-muted hover:text-primary">
            Our Reviews
          </a>
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          <a href={PHONE_TEL} className="inline-flex items-center gap-2 rounded-md border border-border px-4 py-2.5 text-sm font-medium text-foreground transition hover:border-gold hover:text-primary">
            <Phone className="size-4" />Call Now
          </a>
          <button type="button" onClick={() => openBooking()} className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90">
            Book an Appointment
          </button>
        </div>
        <button type="button" className="rounded-md p-2 text-foreground lg:hidden" aria-label={mobileOpen ? 'Close menu' : 'Open menu'} aria-expanded={mobileOpen} onClick={() => setMobileOpen((v) => !v)}>
          {mobileOpen ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>
      {mobileOpen && (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6" aria-label="Mobile">
            <MobileGroup label="About" items={aboutLinks} onNavigate={() => setMobileOpen(false)} />
            <MobileGroup label="Treatments & Specialities" items={treatments} onNavigate={() => setMobileOpen(false)} />
            <a href="#reviews" onClick={() => setMobileOpen(false)} className="block rounded-md px-4 py-3 text-sm font-medium text-foreground/80 transition hover:bg-muted hover:text-primary">
              Our Reviews
            </a>
            <div className="flex flex-col gap-3 pt-3">
              <a href={PHONE_TEL} className="inline-flex items-center justify-center gap-2 rounded-md border border-border px-4 py-3 text-sm font-medium text-foreground"><Phone className="size-4" />Call Now: {PHONE_DISPLAY}</a>
              <button type="button" onClick={() => { setMobileOpen(false); openBooking() }} className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground">Book an Appointment</button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}

function NavDropdown({ label, items }: { label: string; items: { label: string; href: string }[] }) {
  return (
    <div className="group relative">
      <button type="button" className="inline-flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition group-hover:bg-muted group-hover:text-primary">
        {label}<ChevronDown className="size-3.5 transition group-hover:rotate-180" />
      </button>
      <div className="invisible absolute left-0 top-full min-w-56 translate-y-1 rounded-lg border border-border bg-card p-1.5 opacity-0 shadow-lg transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
        {items.map((item) => <a key={item.label} href={item.href} className="block rounded-md px-3 py-2 text-sm text-foreground/80 transition hover:bg-muted hover:text-primary">{item.label}</a>)}
      </div>
    </div>
  )
}

function MobileGroup({ label, items, onNavigate }: { label: string; items: { label: string; href: string }[]; onNavigate: () => void }) {
  return (
    <div className="border-b border-border/60 py-2">
      <p className="px-1 py-1 text-xs font-semibold uppercase tracking-wider text-gold">{label}</p>
      <div className="flex flex-col">
        {items.map((item) => <a key={item.label} href={item.href} onClick={onNavigate} className="rounded-md px-1 py-2 text-sm text-foreground/80 transition hover:text-primary">{item.label}</a>)}
      </div>
    </div>
  )
}