export const PHONE = '+917387494713'
export const PHONE_DISPLAY = '+91 73874 94713'
export const PHONE_TEL = 'tel:+917387494713'
export const WHATSAPP_NUMBER = '917387494713'
export const EMAIL = 'toothlinewellness@gmail.com'
export const ADDRESS =
  'Ground Floor, Tushar Kunj, Kalyani Nagar - Wadgaon Sheri Rd, Adarsh Nagar, Wadgaon Sheri, Pune, Maharashtra 411014'

export const MAPS_LINK =
  'https://maps.google.com/maps?cid=16905571237461698041'

export const SOCIALS = {
  instagram: 'https://instagram.com',
  facebook: 'https://facebook.com',
  whatsapp: 'https://wa.me/917387494713',
  maps: MAPS_LINK,
}

export const SERVICES = [
  'General Consultation & Check-up',
  'Laser Dentistry',
  'Gum Care & Periodontics',
  'Root Canal Treatment',
  'Dental Implants',
  'Cosmetic Dentistry & Whitening',
] as const

export const LOCALITIES = [
  'Wadgaon Sheri',
  'Kalyani Nagar',
  'Viman Nagar',
  'Kharadi',
  'Other',
] as const

export const TIME_SLOTS = [
  { group: 'Morning Session', slot: '10:00 AM - 12:00 PM' },
  { group: 'Morning Session', slot: '12:00 PM - 02:00 PM' },
  { group: 'Evening Session', slot: '05:00 PM - 07:00 PM' },
  { group: 'Evening Session', slot: '07:00 PM - 09:00 PM' },
] as const

export const SERVICE_AREAS = [
  'Wadgaon Sheri',
  'Kalyani Nagar',
  'Viman Nagar',
  'Kharadi',
] as const