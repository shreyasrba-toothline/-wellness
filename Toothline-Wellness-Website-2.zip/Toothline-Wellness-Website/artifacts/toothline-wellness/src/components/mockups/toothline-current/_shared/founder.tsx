import { CalendarCheck, GraduationCap, Award, Heart } from 'lucide-react'
import { useBooking } from './booking-provider'

const credentials = [
  { icon: GraduationCap, title: 'MDS Periodontics', text: 'Master of Dental Surgery with specialisation in periodontics & laser dentistry.' },
  { icon: Award, title: 'Laser Specialist', text: 'Expertise in painless laser therapies, gum restoration & dental implants.' },
  { icon: Heart, title: 'Gentle Care Philosophy', text: 'Focused on minimally invasive techniques and maximum patient comfort.' },
]

export function Founder() {
  const { openBooking } = useBooking()
  return (
    <section id="founder" className="scroll-mt-20 bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="relative mx-auto w-full max-w-md lg:max-w-none">
            <div className="absolute -left-4 -top-4 h-full w-full rounded-3xl border border-gold/40" />
            <div className="relative overflow-hidden rounded-3xl border border-border bg-card shadow-lg">
              <img src="/images/toothline-dr-rufi-bhayani.webp" alt="Dr. Rufi Bhayani at Toothline Wellness" className="aspect-4/5 w-full object-cover" loading="lazy" />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-foreground/80 to-transparent p-6">
                <p className="font-serif text-2xl font-semibold text-background">Dr. Rufi Bhayani</p>
                <p className="text-sm text-background/80">MDS · Periodontist &amp; Laser Specialist</p>
              </div>
            </div>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Founder &amp; Lead Doctor</p>
            <h2 className="mt-3 font-serif text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">Meet Dr. Rufi Bhayani, MDS</h2>
            <p className="mt-5 text-lg leading-relaxed text-muted-foreground">A dedicated periodontist and laser specialist, Dr. Rufi brings years of expertise in painless laser therapies, gum restoration, dental implants, and preventive care. Her practice is built on gentle, patient-first treatment with a focus on minimally invasive techniques and lasting oral health.</p>
            <div className="mt-8 space-y-4">
              {credentials.map((c) => <div key={c.title} className="flex gap-4">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-card text-primary shadow-sm"><c.icon className="size-5" /></span>
                <div><h3 className="font-semibold text-foreground">{c.title}</h3><p className="text-sm leading-relaxed text-muted-foreground">{c.text}</p></div>
              </div>)}
            </div>
            <button type="button" onClick={() => openBooking({ withDrRufi: true })} className="mt-9 inline-flex items-center justify-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90"><CalendarCheck className="size-4.5" />Book Consultation with Dr. Rufi</button>
          </div>
        </div>
      </div>
    </section>
  )
}