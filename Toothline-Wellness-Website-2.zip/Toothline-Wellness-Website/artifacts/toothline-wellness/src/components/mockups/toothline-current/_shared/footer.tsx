import { Phone, Mail, MapPin, Clock, CalendarCheck, MessageCircle, ArrowUpRight } from 'lucide-react'
import type { ReactNode } from 'react'
import { Logo } from './logo'
import { useBooking } from './booking-provider'
import { ADDRESS, EMAIL, MAPS_LINK, PHONE_DISPLAY, PHONE_TEL, SOCIALS } from './site'

export function Footer() {
  const { openBooking } = useBooking()
  return (
    <footer id="contact" className="bg-primary text-primary-foreground">
      <div className="border-b border-primary-foreground/15">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 py-16 text-center sm:px-6 lg:px-8">
          <h2 className="max-w-2xl font-serif text-3xl font-semibold sm:text-4xl">Ready for a Healthier, Brighter Smile?</h2>
          <p className="max-w-xl text-primary-foreground/80">Book your appointment today and experience premium, painless dentistry at Toothline Wellness.</p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <button type="button" onClick={() => openBooking()} className="inline-flex items-center justify-center gap-2 rounded-md bg-champagne px-7 py-3.5 text-sm font-semibold text-primary shadow-sm transition hover:bg-champagne/90"><CalendarCheck className="size-4.5" />Book an Appointment</button>
            <a href={PHONE_TEL} className="inline-flex items-center justify-center gap-2 rounded-md border border-primary-foreground/30 px-7 py-3.5 text-sm font-semibold text-primary-foreground transition hover:bg-primary-foreground/10"><Phone className="size-4.5" />{PHONE_DISPLAY}</a>
          </div>
        </div>
      </div>
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-5 lg:px-8">
        <div className="lg:col-span-1">
          <div className="[&_span]:text-primary-foreground [&_.text-gold]:text-champagne"><Logo /></div>
          <p className="mt-4 text-sm leading-relaxed text-primary-foreground/75">Advanced laser dental care delivered with warmth, precision, and a gentle touch.</p>
          <div className="mt-5 flex gap-3">
            <SocialLink href={SOCIALS.whatsapp} label="WhatsApp"><MessageCircle className="size-4.5" /></SocialLink>
          </div>
        </div>
        <div>
          <h3 className="font-serif text-lg font-semibold">Contact</h3>
          <ul className="mt-4 space-y-3 text-sm text-primary-foreground/80">
            <li><a href={PHONE_TEL} className="flex items-center gap-3 transition hover:text-champagne"><Phone className="size-4 shrink-0 text-champagne" />{PHONE_DISPLAY}</a></li>
            <li><a href={`mailto:${EMAIL}`} className="flex items-center gap-3 transition hover:text-champagne"><Mail className="size-4 shrink-0 text-champagne" />{EMAIL}</a></li>
          </ul>
        </div>
        <div className="lg:col-span-2">
          <h3 className="font-serif text-lg font-semibold">Visit Us</h3>
          <p className="mt-4 flex gap-3 text-sm text-primary-foreground/80"><MapPin className="mt-0.5 size-4 shrink-0 text-champagne" /><span>{ADDRESS}</span></p>
          <div className="mt-4 overflow-hidden rounded-xl border border-primary-foreground/20">
            <iframe
              title="Map to Toothline Wellness"
              src={`${MAPS_LINK}&output=embed`}
              className="h-48 w-full border-0"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
          <a
            href={MAPS_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-champagne transition hover:text-white"
          >
            Get directions
            <ArrowUpRight className="size-4" />
          </a>
        </div>
        <div>
          <h3 className="font-serif text-lg font-semibold">Clinic Hours</h3>
          <ul className="mt-4 space-y-3 text-sm text-primary-foreground/80">
            <li className="flex gap-3"><Clock className="mt-0.5 size-4 shrink-0 text-champagne" /><span><span className="block font-medium text-primary-foreground">Mon – Sat</span>10:00 AM – 2:00 PM<br />5:00 PM – 9:00 PM</span></li>
            <li className="flex gap-3"><Clock className="mt-0.5 size-4 shrink-0 text-primary-foreground/40" /><span><span className="block font-medium text-primary-foreground">Sunday</span>Closed</span></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/15">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-6 text-xs text-primary-foreground/60 sm:flex-row sm:px-6 lg:px-8">
          <p>© {new Date().getFullYear()} Toothline Wellness · Laser Dental Care. All rights reserved.</p>
          <p>Wadgaon Sheri · Kalyani Nagar · Viman Nagar · Kharadi, Pune</p>
        </div>
      </div>
    </footer>
  )
}

function SocialLink({ href, label, children }: { href: string; label: string; children: ReactNode }) {
  return <a href={href} target="_blank" rel="noopener noreferrer" aria-label={label} className="flex size-9 items-center justify-center rounded-full border border-primary-foreground/25 text-primary-foreground transition hover:border-champagne hover:bg-primary-foreground/10 hover:text-champagne">{children}</a>
}
