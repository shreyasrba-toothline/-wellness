import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { BookingModal } from './booking-modal'
import { SERVICES } from './site'

type ServiceName = (typeof SERVICES)[number]
type BookingPrefill = { service?: ServiceName; withDrRufi?: boolean }
type BookingContextValue = {
  open: boolean
  prefill: BookingPrefill
  openBooking: (prefill?: BookingPrefill) => void
  closeBooking: () => void
}

const BookingContext = createContext<BookingContextValue | null>(null)

export function BookingProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false)
  const [prefill, setPrefill] = useState<BookingPrefill>({})

  const openBooking = useCallback((next: BookingPrefill = {}) => {
    setPrefill(next)
    setOpen(true)
  }, [])
  const closeBooking = useCallback(() => setOpen(false), [])
  const value = useMemo(
    () => ({ open, prefill, openBooking, closeBooking }),
    [open, prefill, openBooking, closeBooking],
  )

  return (
    <BookingContext.Provider value={value}>
      {children}
      <BookingModal />
    </BookingContext.Provider>
  )
}

export function useBooking() {
  const ctx = useContext(BookingContext)
  if (!ctx) throw new Error('useBooking must be used within a BookingProvider')
  return ctx
}