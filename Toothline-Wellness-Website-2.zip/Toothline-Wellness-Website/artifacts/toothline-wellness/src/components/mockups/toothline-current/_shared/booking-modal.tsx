import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { X, CalendarCheck, CheckCircle2 } from 'lucide-react'
import { useBooking } from './booking-provider'
import { LOCALITIES, SERVICES, TIME_SLOTS, WHATSAPP_NUMBER } from './site'

function toISODate(d: Date) {
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function slotStartMinutes(slot: string) {
  const [time, period] = slot.split(' - ')[0].split(' ')
  const [hours, minutes] = time.split(':').map(Number)
  return ((hours % 12) + (period === 'PM' ? 12 : 0)) * 60 + minutes
}

type Errors = { fullName?: string; mobile?: string; date?: string; timeSlot?: string }

export function BookingModal() {
  const { open, prefill, closeBooking } = useBooking()
  const [now, setNow] = useState(() => new Date())
  const minDate = toISODate(now)
  const maxDate = useMemo(() => {
    const d = new Date(now)
    d.setDate(d.getDate() + 15)
    return toISODate(d)
  }, [minDate])
  const [fullName, setFullName] = useState('')
  const [mobile, setMobile] = useState('')
  const [service, setService] = useState<string>('-')
  const [date, setDate] = useState('')
  const [timeSlot, setTimeSlot] = useState('')
  const [locality, setLocality] = useState('')
  const [errors, setErrors] = useState<Errors>({})
  const [confirmed, setConfirmed] = useState(false)
  const dialogRef = useRef<HTMLDivElement>(null)
  const firstFieldRef = useRef<HTMLInputElement>(null)
  const availableTimeSlots = useMemo(() => {
    if (date !== minDate) return TIME_SLOTS
    const earliestStart = now.getHours() * 60 + now.getMinutes() + 120
    return TIME_SLOTS.filter((slot) => slotStartMinutes(slot.slot) >= earliestStart)
  }, [date, minDate, now])

  useEffect(() => {
    if (!open) return
    const refreshTime = () => setNow(new Date())
    refreshTime()
    const interval = window.setInterval(refreshTime, 30_000)
    return () => window.clearInterval(interval)
  }, [open])

  useEffect(() => {
    if (open) {
      setFullName('')
      setMobile('')
      setService(prefill.service ?? '-')
      setDate('')
      setTimeSlot('')
      setLocality('')
      setErrors({})
      setConfirmed(false)
    }
  }, [open, prefill])

  useEffect(() => {
    if (timeSlot && !availableTimeSlots.some((slot) => slot.slot === timeSlot)) {
      setTimeSlot('')
    }
  }, [availableTimeSlots, timeSlot])

  useEffect(() => {
    if (!open) return
    const previousFocus = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null
    firstFieldRef.current?.focus()
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeBooking()
        return
      }
      if (e.key !== 'Tab') return
      const focusable = dialogRef.current?.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
      )
      if (!focusable?.length) return
      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }
    document.addEventListener('keydown', onKey)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
      if (previousFocus?.isConnected) previousFocus.focus()
    }
  }, [open, closeBooking])

  if (!open) return null

  function validate(): boolean {
    const next: Errors = {}
    if (!fullName.trim()) next.fullName = 'Please enter your full name.'
    const digits = mobile.replace(/\D/g, '')
    if (!mobile.trim()) next.mobile = 'Please enter your mobile number.'
    else if (digits.length < 10) next.mobile = 'Please enter a valid mobile number.'
    if (!date || date < minDate || date > maxDate) {
      next.date = 'Please choose a date within the next 15 days.'
    }
    if (!timeSlot || !availableTimeSlots.some((slot) => slot.slot === timeSlot)) {
      next.timeSlot = 'Please select an available time slot.'
    }
    setErrors(next)
    return Object.keys(next).length === 0
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!validate()) return
    setConfirmed(true)
  }

  const fieldBase = 'w-full rounded-md border border-border bg-background px-3.5 py-2.5 text-sm text-foreground outline-none transition focus:border-gold focus:ring-2 focus:ring-gold/30'
  const formattedDate = date
    ? new Date(date + 'T00:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    : ''

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center overflow-y-auto bg-foreground/50 p-0 backdrop-blur-sm sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-labelledby="booking-title" onClick={closeBooking}>
      <div ref={dialogRef} className="relative w-full max-w-lg rounded-t-2xl border border-border bg-card shadow-2xl sm:rounded-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-4 border-b border-border px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary"><CalendarCheck className="size-5" /></span>
            <div>
              <h2 id="booking-title" className="font-serif text-2xl leading-tight text-foreground">{prefill.withDrRufi ? 'Book with Dr. Rufi' : 'Book an Appointment'}</h2>
              <p className="text-xs text-muted-foreground">{confirmed ? 'Your request is ready to send.' : 'Share your preferred details with our team on WhatsApp.'}</p>
            </div>
          </div>
          <button type="button" onClick={closeBooking} aria-label="Close booking form" className="rounded-full p-1.5 text-muted-foreground transition hover:bg-muted hover:text-foreground"><X className="size-5" /></button>
        </div>

        {confirmed ? (
          <div className="px-6 py-8">
            <div className="flex flex-col items-center text-center">
              <span className="flex size-14 items-center justify-center rounded-full bg-secondary text-primary"><CheckCircle2 className="size-7" /></span>
              <h3 className="mt-4 font-serif text-2xl font-semibold text-foreground">Appointment request noted</h3>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">Review your request in WhatsApp and press send to contact the clinic. Your appointment is not confirmed until the team replies.</p>
            </div>
            <dl className="mt-6 space-y-2 rounded-xl bg-secondary/50 p-4 text-sm">
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Name</dt><dd className="text-right font-medium text-foreground">{fullName.trim()}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Mobile</dt><dd className="text-right font-medium text-foreground">{mobile.trim()}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Service</dt><dd className="text-right font-medium text-foreground">{service === '-' ? 'No services selected' : service}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Date</dt><dd className="text-right font-medium text-foreground">{formattedDate}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Time</dt><dd className="text-right font-medium text-foreground">{timeSlot}</dd></div>
              {locality && <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Locality</dt><dd className="text-right font-medium text-foreground">{locality}</dd></div>}
            </dl>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
                [
                  `Hello Toothline Wellness, I’d like to request an appointment${prefill.withDrRufi ? ' with Dr. Rufi' : ''}.`,
                  `Name: ${fullName.trim()}`,
                  `Mobile: ${mobile.trim()}`,
                  `Service: ${service === '-' ? 'No services selected' : service}`,
                  `Preferred date: ${formattedDate}`,
                  `Preferred time: ${timeSlot}`,
                  locality ? `Locality: ${locality}` : '',
                ]
                  .filter(Boolean)
                  .join('\n'),
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 flex w-full items-center justify-center rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90"
            >
              Send request on WhatsApp
            </a>
            <button type="button" onClick={closeBooking} className="mt-2 w-full rounded-md border border-border px-4 py-3 text-sm font-semibold text-foreground transition hover:bg-muted">Close</button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="max-h-[75vh] space-y-4 overflow-y-auto px-6 py-5">
            <div>
              <label htmlFor="bk-name" className="mb-1.5 block text-sm font-medium text-foreground">Full Name <span className="text-destructive">*</span></label>
               <input ref={firstFieldRef} id="bk-name" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="e.g. Priya Sharma" className={fieldBase} aria-invalid={!!errors.fullName} aria-describedby={errors.fullName ? 'bk-name-error' : undefined} />
               {errors.fullName && <p id="bk-name-error" className="mt-1 text-xs text-destructive">{errors.fullName}</p>}
            </div>
            <div>
              <label htmlFor="bk-mobile" className="mb-1.5 block text-sm font-medium text-foreground">Mobile Number <span className="text-destructive">*</span></label>
               <input id="bk-mobile" type="tel" inputMode="tel" value={mobile} onChange={(e) => setMobile(e.target.value)} placeholder="e.g. 98765 43210" className={fieldBase} aria-invalid={!!errors.mobile} aria-describedby={errors.mobile ? 'bk-mobile-error' : undefined} />
               {errors.mobile && <p id="bk-mobile-error" className="mt-1 text-xs text-destructive">{errors.mobile}</p>}
            </div>
            <div>
              <label htmlFor="bk-service" className="mb-1.5 block text-sm font-medium text-foreground">Service Required</label>
               <select id="bk-service" value={service} onChange={(e) => setService(e.target.value)} className={fieldBase}>
                 <option value="-">No specific service</option>
                 {SERVICES.map((s) => <option key={s} value={s}>{s}</option>)}
               </select>
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="bk-date" className="mb-1.5 block text-sm font-medium text-foreground">Preferred Date <span className="text-destructive">*</span></label>
                  <input id="bk-date" type="date" value={date} min={minDate} max={maxDate} onChange={(e) => { setDate(e.target.value); setTimeSlot('') }} className={fieldBase} aria-invalid={!!errors.date} aria-describedby={errors.date ? 'bk-date-error' : undefined} />
                 {errors.date && <p id="bk-date-error" className="mt-1 text-xs text-destructive">{errors.date}</p>}
              </div>
              <div>
                <label htmlFor="bk-time" className="mb-1.5 block text-sm font-medium text-foreground">Preferred Time <span className="text-destructive">*</span></label>
                 <select id="bk-time" value={timeSlot} onChange={(e) => setTimeSlot(e.target.value)} className={fieldBase} aria-invalid={!!errors.timeSlot} aria-describedby={errors.timeSlot ? 'bk-time-error' : undefined}>
                   <option value="" disabled>Select a slot</option>
                   {(['Morning Session', 'Evening Session'] as const).map((group) => {
                     const slots = availableTimeSlots.filter((t) => t.group === group)
                     return slots.length ? (
                       <optgroup key={group} label={group}>
                         {slots.map((t) => <option key={t.slot} value={t.slot}>{t.slot}</option>)}
                       </optgroup>
                     ) : null
                   })}
                </select>
                 {errors.timeSlot && <p id="bk-time-error" className="mt-1 text-xs text-destructive">{errors.timeSlot}</p>}
                  {date === minDate && availableTimeSlots.length === 0 && <p className="mt-1 text-xs text-muted-foreground">No same-day slots remain with two hours’ notice. Please choose another date.</p>}
              </div>
            </div>
            <div>
              <label htmlFor="bk-locality" className="mb-1.5 block text-sm font-medium text-foreground">Locality <span className="text-muted-foreground">(optional)</span></label>
              <select id="bk-locality" value={locality} onChange={(e) => setLocality(e.target.value)} className={fieldBase}>
                <option value="">Select your locality</option>{LOCALITIES.map((l) => <option key={l} value={l}>{l}</option>)}
              </select>
            </div>
            <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold tracking-wide text-primary-foreground transition hover:bg-primary/90"><CalendarCheck className="size-4" />Send request on WhatsApp</button>
            <p className="text-center text-xs text-muted-foreground">Nothing is sent until you open WhatsApp and press send.</p>
          </form>
        )}
      </div>
    </div>
  )
}