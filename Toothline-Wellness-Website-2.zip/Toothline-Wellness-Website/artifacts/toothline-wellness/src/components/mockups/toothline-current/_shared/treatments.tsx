import { Zap, Sparkles, Activity, Anchor, Smile, Stethoscope, ArrowRight } from 'lucide-react'
import { useBooking } from './booking-provider'
import { SERVICES } from './site'

const treatments = [
  { icon: Zap, service: SERVICES[1], title: 'Laser Dentistry', text: 'Precise, painless procedures with faster healing and no drills or discomfort.' },
  { icon: Activity, service: SERVICES[2], title: 'Gum Care & Periodontics', text: 'Specialist treatment for bleeding gums, recession, and periodontal health.' },
  { icon: Stethoscope, service: SERVICES[3], title: 'Root Canal Treatment', text: 'Comfortable, single-visit root canals that save your natural teeth.' },
  { icon: Anchor, service: SERVICES[4], title: 'Dental Implants', text: 'Permanent, natural-looking replacements for missing teeth.' },
  { icon: Smile, service: SERVICES[5], title: 'Cosmetic Dentistry', text: 'Smile design, veneers, and teeth whitening for a radiant confident smile.' },
  { icon: Sparkles, service: SERVICES[0], title: 'General Check-up', text: 'Thorough examinations and preventive care to keep your smile healthy.' },
] as const

export function Treatments() {
  const { openBooking } = useBooking()
  return (
    <section id="treatments" className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Treatments &amp; Specialities</p>
          <h2 className="mt-3 font-serif text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">Comprehensive, Gentle Dental Care</h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">From routine check-ups to advanced laser procedures, every treatment is delivered with precision and comfort in mind.</p>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {treatments.map((t) => <button key={t.title} type="button" onClick={() => openBooking({ service: t.service })} className="group flex flex-col items-start rounded-2xl border border-border bg-card p-7 text-left shadow-sm transition hover:-translate-y-1 hover:border-gold/50 hover:shadow-md">
            <span className="flex size-12 items-center justify-center rounded-xl bg-secondary text-primary transition group-hover:bg-primary group-hover:text-primary-foreground"><t.icon className="size-6" /></span>
            <h3 className="mt-5 font-serif text-xl font-semibold text-foreground">{t.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t.text}</p>
            <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary">Book this treatment<ArrowRight className="size-4 transition group-hover:translate-x-1" /></span>
          </button>)}
        </div>
        <div className="mt-10 flex justify-center">
          <a
            href="/services"
            className="inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:-translate-y-0.5 hover:bg-primary/90"
          >
            Browse all our services
            <ArrowRight className="size-4" />
          </a>
        </div>
      </div>
    </section>
  )
}