import { ShieldCheck, Star } from 'lucide-react'
import { MAPS_LINK } from './site'

export function Reviews() {
  return (
    <section id="reviews" className="overflow-hidden bg-secondary/40 py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center gap-6 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Patient Stories</p>
          <h2 className="font-serif text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">Original Google Reviews</h2>
          <p className="max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            Visit Toothline Wellness on Google. We’re not displaying review quotes until they can be verified against the clinic’s original listing.
          </p>
          <div className="mt-2 flex w-full max-w-3xl flex-col items-center gap-4 rounded-2xl border border-border bg-card p-6 text-center shadow-sm sm:flex-row sm:text-left">
            <span className="flex size-12 shrink-0 items-center justify-center rounded-full bg-secondary text-primary">
              <ShieldCheck className="size-6" aria-hidden="true" />
            </span>
            <div className="flex-1">
              <p className="font-semibold text-foreground">No unverified quotes.</p>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                No unverified patient quotes are shown. The clinic profile is available on Google while the original reviews are being confirmed.
              </p>
            </div>
            <a
              href={MAPS_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex shrink-0 items-center gap-2 rounded-md border border-border px-4 py-2.5 text-sm font-semibold text-foreground transition hover:border-gold hover:text-primary"
            >
              <Star className="size-4" aria-hidden="true" />
              View Google profile
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}