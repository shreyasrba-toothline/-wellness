import { MessageCircle } from 'lucide-react'
import { SOCIALS } from './site'

export function WhatsAppFab() {
  return (
    <a href={SOCIALS.whatsapp} target="_blank" rel="noopener noreferrer" aria-label="Chat with Toothline Wellness on WhatsApp" className="fixed bottom-5 right-5 z-40 flex size-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg transition hover:scale-105 hover:shadow-xl">
      <MessageCircle className="size-7" />
    </a>
  )
}