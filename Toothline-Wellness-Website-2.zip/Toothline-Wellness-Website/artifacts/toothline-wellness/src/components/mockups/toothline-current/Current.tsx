import { useEffect, useState } from 'react'
import { CalendarCheck, ChevronDown, Menu, Phone, ShieldCheck, Star, X } from 'lucide-react'
import './_group.css'
import { BookingProvider, useBooking } from './_shared/booking-provider'
import { About } from './_shared/about'
import { Founder } from './_shared/founder'
import { Treatments } from './_shared/treatments'
import { Reviews } from './_shared/reviews'
import { ServiceAreas } from './_shared/service-areas'
import { Footer } from './_shared/footer'
import { WhatsAppFab } from './_shared/whatsapp-fab'
import { PHONE_DISPLAY, PHONE_TEL } from './_shared/site'

const aboutLinks = [
  { label: 'Our Clinic', href: '#about' },
  { label: 'Our Doctors', href: '#founder' },
]

const servicePreview = '/services'

const treatmentLinks = [
  { label: 'Browse all services', href: servicePreview },
  { label: 'Laser Dentistry', href: `${servicePreview}/laser-dentistry-laser-gum-therapy` },
  { label: 'Gum Care & Periodontics', href: `${servicePreview}/periodontal-and-gum-care` },
  { label: 'Root Canal Treatment', href: `${servicePreview}/root-canal-treatment` },
  { label: 'Dental Implants', href: `${servicePreview}/single-tooth-implants` },
  { label: 'Cosmetic Dentistry', href: `${servicePreview}/teeth-whitening` },
]

function Header() {
  const { openBooking } = useBooking()
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const solidHeader = scrolled || mobileOpen
  const linkTone = solidHeader
    ? 'text-foreground/80 hover:bg-muted hover:text-primary'
    : 'text-white/80 hover:bg-white/10 hover:text-white'

  useEffect(() => {
    const updateHeader = () => setScrolled(window.scrollY > 24)
    updateHeader()
    window.addEventListener('scroll', updateHeader, { passive: true })
    return () => window.removeEventListener('scroll', updateHeader)
  }, [])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [mobileOpen])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 border-b transition-all duration-700 ease-in-out ${
        solidHeader
          ? 'border-border bg-white shadow-[0_5px_24px_rgba(54,39,25,0.08)]'
          : 'border-transparent bg-transparent shadow-none'
      }`}
    >
      <div className="mx-auto flex h-[74px] max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        <a href="/" className="group block shrink-0" aria-label="Toothline Wellness — Laser Dental Care, home">
          <img
            src="/images/toothline-current-logo-transparent.png"
            alt="Toothline Wellness laser dental care"
            className={`h-12 w-auto max-w-[190px] object-contain object-left transition-[filter,opacity] duration-700 ease-in-out sm:h-14 sm:max-w-[220px] ${
              solidHeader ? 'opacity-80 brightness-0' : 'opacity-90 brightness-0 invert'
            }`}
          />
        </a>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          <NavDropdown label="About" items={aboutLinks} linkTone={linkTone} />
          <NavDropdown label="Treatments & Specialities" items={treatmentLinks} linkTone={linkTone} />
          <a href="#reviews" className={`rounded-md px-3 py-2 text-sm font-medium transition-colors ${linkTone}`}>
            Our Reviews
          </a>
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href={PHONE_TEL}
            className={`inline-flex items-center gap-2 rounded-md border px-4 py-2.5 text-sm font-medium transition-all duration-700 ${
              solidHeader
                ? 'border-border text-foreground hover:border-gold hover:text-primary'
                : 'border-white/40 text-white/85 hover:border-white/70 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Phone className="size-4" />
            Call Now
          </a>
          <button
            type="button"
            onClick={() => openBooking()}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-sm transition hover:bg-primary/90"
          >
            Book an Appointment
          </button>
        </div>

        <button
          type="button"
          className={`rounded-md p-2 transition-colors duration-700 lg:hidden ${
            solidHeader ? 'text-foreground' : 'text-white/85 hover:text-white'
          }`}
          aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((open) => !open)}
        >
          {mobileOpen ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-border bg-white lg:hidden">
          <nav className="mx-auto max-w-7xl space-y-1 px-4 py-4 sm:px-6" aria-label="Mobile">
            <MobileGroup label="About" items={aboutLinks} onNavigate={() => setMobileOpen(false)} />
            <MobileGroup label="Treatments & Specialities" items={treatmentLinks} onNavigate={() => setMobileOpen(false)} />
            <a
              href="#reviews"
              onClick={() => setMobileOpen(false)}
              className="block rounded-md px-4 py-3 text-sm font-medium text-foreground/80 transition hover:bg-muted hover:text-primary"
            >
              Our Reviews
            </a>
            <div className="flex flex-col gap-3 pt-3">
              <a
                href={PHONE_TEL}
                className="inline-flex items-center justify-center gap-2 rounded-md border border-border px-4 py-3 text-sm font-medium text-foreground"
              >
                <Phone className="size-4" />
                Call Now: {PHONE_DISPLAY}
              </a>
              <button
                type="button"
                onClick={() => {
                  setMobileOpen(false)
                  openBooking()
                }}
                className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground"
              >
                Book an Appointment
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}

function NavDropdown({
  label,
  items,
  linkTone,
}: {
  label: string
  items: { label: string; href: string }[]
  linkTone: string
}) {
  return (
    <div className="group relative">
      <button
        type="button"
        className={`inline-flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium transition-colors duration-700 ${linkTone}`}
      >
        {label}
        <ChevronDown className="size-3.5 transition-transform group-hover:rotate-180" />
      </button>
      <div className="invisible absolute left-0 top-full min-w-56 translate-y-1 rounded-lg border border-border bg-white p-1.5 text-foreground opacity-0 shadow-lg transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100">
        {items.map((item) => (
          <a
            key={item.label}
            href={item.href}
            className="block rounded-md px-3 py-2 text-sm text-foreground/80 transition hover:bg-muted hover:text-primary"
          >
            {item.label}
          </a>
        ))}
      </div>
    </div>
  )
}

function MobileGroup({
  label,
  items,
  onNavigate,
}: {
  label: string
  items: { label: string; href: string }[]
  onNavigate: () => void
}) {
  return (
    <div className="border-b border-border/60 py-2">
      <p className="px-1 py-1 text-xs font-semibold uppercase tracking-wider text-gold">{label}</p>
      <div className="flex flex-col">
        {items.map((item) => (
          <a
            key={item.label}
            href={item.href}
            onClick={onNavigate}
            className="rounded-md px-1 py-2 text-sm text-foreground/80 transition hover:text-primary"
          >
            {item.label}
          </a>
        ))}
      </div>
    </div>
  )
}

const clinicSlides = [
  { src: '/images/toothline-current-clinic-1.webp', alt: 'Toothline Wellness treatment room and reception desk' },
  { src: '/images/toothline-current-clinic-2.webp', alt: 'Toothline Wellness clinic wall and reception area' },
  { src: '/images/toothline-current-clinic-3.webp', alt: 'Dental treatment room at Toothline Wellness' },
  { src: '/images/toothline-current-clinic-4.webp', alt: 'Toothline Wellness clinic with warm accent lighting' },
  { src: '/images/toothline-current-clinic-5.webp', alt: 'Welcoming Toothline Wellness reception' },
  { src: '/images/toothline-current-clinic-6.webp', alt: 'Toothline Wellness clinic sign' },
]

function ClinicHero() {
  const { openBooking } = useBooking()
  const [index, setIndex] = useState(0)

  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const id = window.setInterval(() => {
      setIndex((current) => (current + 1) % clinicSlides.length)
    }, 5000)
    return () => window.clearInterval(id)
  }, [])

  return (
    <section id="top" className="relative isolate min-h-[92vh] w-full overflow-hidden">
      <div
        className="absolute inset-0 flex h-full transition-transform duration-[1200ms] ease-in-out"
        style={{
          width: `${clinicSlides.length * 100}%`,
          transform: `translateX(-${index * (100 / clinicSlides.length)}%)`,
        }}
        aria-hidden="true"
      >
        {clinicSlides.map((slide) => (
          <div key={slide.src} className="relative h-full" style={{ width: `${100 / clinicSlides.length}%` }}>
            <img src={slide.src} alt={slide.alt} className="animate-hero-pan h-full w-full object-cover" />
          </div>
        ))}
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/55 to-foreground/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-background/40 via-transparent to-transparent" />
      <div className="relative mx-auto flex min-h-[92vh] max-w-7xl items-center px-4 pb-16 pt-28 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-champagne/40 bg-background/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-champagne backdrop-blur-sm">
            <Star className="size-3.5 fill-champagne text-champagne" />
            Gentle Laser Dentistry · Pune
          </span>
          <h1 className="mt-6 font-serif text-4xl font-semibold leading-[1.08] text-background sm:text-5xl lg:text-6xl">Advanced Laser Dental Care in New Kalyani Nagar, Pune</h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-background/85">
            Experience gentle, painless, and minimally invasive dental treatments under expert care.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button
              type="button"
              onClick={() => openBooking()}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-lg transition hover:bg-primary/90"
            >
              <CalendarCheck className="size-4.5" />
              Book an Appointment
            </button>
            <a
              href={PHONE_TEL}
              className="inline-flex items-center justify-center gap-2 rounded-md border border-champagne/50 bg-background/10 px-7 py-3.5 text-sm font-semibold text-background backdrop-blur-sm transition hover:bg-background/20"
            >
              <Phone className="size-4.5" />
              Call Now: {PHONE_DISPLAY}
            </a>
          </div>
          <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-background/80">
            <span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-champagne" />Minimally Invasive</span>
            <span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-champagne" />Painless Treatments</span>
            <span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-champagne" />Expert Periodontist Care</span>
          </div>
        </div>
      </div>
      <div className="absolute bottom-6 left-1/2 z-10 flex -translate-x-1/2 gap-2">
        {clinicSlides.map((slide, slideIndex) => (
          <button
            key={slide.src}
            type="button"
            aria-label={`Show clinic photo ${slideIndex + 1}`}
            aria-current={slideIndex === index}
            onClick={() => setIndex(slideIndex)}
            className={`h-1.5 rounded-full transition-all ${slideIndex === index ? 'w-8 bg-champagne' : 'w-4 bg-background/50'}`}
          />
        ))}
      </div>
    </section>
  );
}

export function Current() {
  return (
    <div className="toothline-current min-h-[100dvh]">
      <BookingProvider>
        <Header />
        <main>
          <ClinicHero />
          <About />
          <Founder />
          <Treatments />
          <Reviews />
          <ServiceAreas />
        </main>
        <Footer />
        <WhatsAppFab />
      </BookingProvider>
    </div>
  )
}