import { MapPin } from 'lucide-react'
import { SERVICE_AREAS } from './site'

const descriptions: Record<string, string> = {
  'Wadgaon Sheri': 'Our home locality — premium laser dental care right around the corner.',
  'Kalyani Nagar': 'Trusted dentistry moments away for Kalyani Nagar residents.',
  'Viman Nagar': 'Convenient, gentle dental treatments for the Viman Nagar community.',
  Kharadi: 'Advanced care within easy reach of Kharadi and Kharadi Gaon.',
}

export function ServiceAreas() {
  return (
    <section id="service-areas" className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-gold">Service Areas</p>
          <h2 className="mt-3 font-serif text-3xl font-semibold text-foreground sm:text-4xl lg:text-5xl">Serving Pune&apos;s East Side</h2>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">Conveniently located to care for patients across Wadgaon Sheri, Kalyani Nagar, Viman Nagar, and Kharadi.</p>
        </div>
        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICE_AREAS.map((area) => <div key={area} className="rounded-2xl border border-border bg-card p-7 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-md">
            <span className="mx-auto flex size-12 items-center justify-center rounded-full bg-secondary text-primary"><MapPin className="size-6" /></span>
            <h3 className="mt-5 font-serif text-xl font-semibold text-foreground">{area}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{descriptions[area]}</p>
          </div>)}
        </div>
      </div>
    </section>
  )
}