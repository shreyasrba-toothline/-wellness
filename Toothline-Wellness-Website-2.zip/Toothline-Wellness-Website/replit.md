# Toothline Wellness Website

A frontend-only website for Toothline Wellness, a dental clinic in Wadgaon Sheri, Pune.

## Run & Operate

- `pnpm --filter @workspace/toothline-wellness run dev` — run the website
- `pnpm --filter @workspace/toothline-wellness run typecheck` — typecheck the website
- The Toothline website does not require an API or database.

## Stack

- React, TypeScript, and Vite in the pnpm workspace
- Local clinic and treatment images are served from the website's `public/images` folder

## Where things live

- `artifacts/toothline-wellness/src/` — editable website pages, shared components, and styles
- `artifacts/toothline-wellness/public/images/` — clinic, staff, logo, and treatment images

## Architecture decisions

- The supplied React/Vite site is the source of truth for the frontend and its content.
- The booking flow stays client-side and prepares a WhatsApp message; submissions are not stored.

## Product

The site introduces the clinic, its care team, location, reviews, and dental services. It includes a frontend booking experience and service landing pages.

## User preferences

- Keep the current scope frontend-only; do not add an API or database unless requested.

## Gotchas

The service pages are served under `/services` and nested `/services/...` routes.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
